cv_bridge
=========

``cv_bridge`` contains a single class :class:`CvBridge` that converts ROS Image messages to 
OpenCV images.

.. module:: cv_bridge

.. autoclass:: cv_bridge.CvBridge
      :members:

.. autoclass:: cv_bridge.CvBridgeError

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
