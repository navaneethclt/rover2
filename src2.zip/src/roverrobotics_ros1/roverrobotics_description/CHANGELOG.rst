^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package roverrobotics_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
2.0.1 (2020-12-14)
------------------

2.0.0 (2020-11-10)
------------------

1.2.0 (2020-11-05)
------------------

1.1.1 (2020-06-15)
------------------
* Flip orrientation of Lidar, and rename launch file names
*  add pyserial to package.xml
* Contributors: 1102, padiln

1.1.0 (2020-06-08)
------------------
* release to melodic

1.0.0 (2020-06-08)
------------------
* Merge branch 'develop' into feature/padiln/rviz_gazebo_sim
* adding rviz and gazebo simulation to rr_openrover stack
* added support for gazebo and rviz simulation for 2wd and 4wd rovers
* Contributors: padiln

0.8.0 (2020-03-25)
------------------

0.7.4 (2020-02-19)
------------------
* change Maintainership
* Adding description and 4WD code
